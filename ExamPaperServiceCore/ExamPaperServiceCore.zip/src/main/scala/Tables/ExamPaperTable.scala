package Tables

import Plugins.ExamPaperServiceShared.ExamPaper
import Plugins.ExamPaperServiceShared.Problem
import Plugins.CommonUtils.ServiceCenter
import Plugins.CommonUtils.TypedSystem.API.PlanUUID
import Plugins.CommonUtils.TypedSystem.EventGenerator.{dbReadAction, dbReadActionSeq, dbWriteAction}
import monix.eval.Task
import slick.jdbc.PostgresProfile.api._
import slick.lifted.{ProvenShape, Tag, TableQuery}

case class ExamPaperRow(
                       index:Option[Int] = None,
                       title:String,
                       problemCnt:Int,
                       examDuration:Int,
                       problems:Array[Problem],
                    )

object Convert{
  def fromProblemToString(problem: Problem): String = {
    ("{" + problem.problemType + "," +
      problem.description + "," +
      problem.image.toString + "," +
      problem.choiceCnt.toString + "," + "[" +
      problem.choices.mkString("/") + "]" + "}")
  }

  def fromStringToProblem(string: String): Problem = {
    val strList = string.replace("{", "").replace("}", "").split(",")
    Problem(strList(0), strList(1), strList(2).toInt, strList(3).toInt,
      strList(4).replace("[", "").replace("]", "").split("/"))
  }

  def fromRowToShared(row: ExamPaperRow): ExamPaper = {
    ExamPaper(row.index.getOrElse(-1), row.title, row.problemCnt, row.examDuration, row.problems)
  }
}

object MyImplicits {
  implicit val arrayProblemColumnType: BaseColumnType[Array[Problem]] = {
    MappedColumnType.base[Array[Problem], String](
      list => list.map(Convert.fromProblemToString).mkString(","),
      string => string.split(",").map(Convert.fromStringToProblem)
    )
  }
}

import MyImplicits._

class ExamPaperTable(tag:Tag) extends Table[ExamPaperRow](tag, ServiceCenter.mainSchema, "examPaper") {
  def index:Rep[Int] = column[Int]("index", O.PrimaryKey, O.AutoInc)
  def title:Rep[String] = column[String]("title")
  def problemCnt:Rep[Int] = column[Int]("problemCnt")
  def examDuration:Rep[Int] = column[Int]("examDuration")
  def problems:Rep[Array[Problem]] = column[Array[Problem]]("problems")

  def * : ProvenShape[ExamPaperRow] = (index.?, title, problemCnt, examDuration, problems).mapTo[ExamPaperRow]
}



object ExamPaperTable{
  val examPaperTable = TableQuery[ExamPaperTable]

  def addPaper(paper:ExamPaper)(implicit uuid:PlanUUID): Task[Int] = {
    val paperRow = ExamPaperRow(title = paper.title, problemCnt = paper.problemCnt,
      examDuration = paper.examDuration, problems = paper.problems)
    dbWriteAction((examPaperTable returning examPaperTable.map(_.index)) += paperRow)
  }

  def deletePaper(index:Int)(implicit uuid:PlanUUID): Task[Int] = {
    dbReadAction(examPaperTable.filter(_.index === index).result.headOption).flatMap {
      case None => Task.raiseError(new Exception(s"Index $index not found!"))
      case Some(row) => dbWriteAction(examPaperTable.filter(_.index === index).delete)
    }
  }

  def getPaper(index:Int)(implicit uuid:PlanUUID): Task[ExamPaper] = {
    dbReadAction(examPaperTable.filter(_.index === index).result.headOption).flatMap{
      case Some(row) => Task.now(ExamPaper(row.index.getOrElse(-1), row.title, row.problemCnt, row.examDuration, row.problems))
      case None => Task.raiseError(new Exception(s"Index $index not found!"))
    }
  }

  def rewritePaper(paper:ExamPaper)(implicit uuid: PlanUUID): Task[Int] = {
    val paperRow = ExamPaperRow(title = paper.title, problemCnt = paper.problemCnt,
      examDuration = paper.examDuration, problems = paper.problems)
    dbReadAction(examPaperTable.filter(_.index === paper.index).result.headOption).flatMap {
      case None => Task.raiseError(new Exception(s"Index $paper.index not found!"))
      case Some(row) => dbWriteAction(examPaperTable.filter(_.index === paper.index).update(paperRow))
    }
  }

  def getAllRows()(implicit uuid: PlanUUID): Task[Array[ExamPaper]] = {
    dbReadAction{
      examPaperTable.result
    }.map(_.toArray.map(__ => Convert.fromRowToShared(__)))
  }

}
