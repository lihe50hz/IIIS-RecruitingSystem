package Plugins.ExamPaperServiceShared

import Plugins.CommonUtils.Types.JacksonSerializable

case class Problem(
  problemType:String,
  description:String,
  image:Int,
  choiceCnt:Int,
  choices:Array[String],
  
) extends JacksonSerializable