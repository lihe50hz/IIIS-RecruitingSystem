
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.CommonUtils.Types.JacksonSerializable
import com.fasterxml.jackson.annotation.{JsonSubTypes, JsonTypeInfo}


@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes(
  Array(
    new JsonSubTypes.Type(value = classOf[ToRecruitingSystemPortalMessage], name = "ToRecruitingSystemPortalMessage"),
    new JsonSubTypes.Type(value = classOf[ToserverMessage], name = "ToserverMessage"),
    new JsonSubTypes.Type(value = classOf[TotestttttttMessage], name = "TotestttttttMessage"),
    new JsonSubTypes.Type(value = classOf[ToUserServiceMessage], name = "ToUserServiceMessage"),
    new JsonSubTypes.Type(value = classOf[ToUserServerMessage], name = "ToUserServerMessage"),
    new JsonSubTypes.Type(value = classOf[ToImageServiceMessage], name = "ToImageServiceMessage"),
    new JsonSubTypes.Type(value = classOf[ToExamPaperServiceMessage], name = "ToExamPaperServiceMessage"),
    new JsonSubTypes.Type(value = classOf[TotestCoreMessage], name = "TotestCoreMessage"),
    new JsonSubTypes.Type(value = classOf[TotestttMessage], name = "TotestttMessage"),
    new JsonSubTypes.Type(value = classOf[ToSignUpServiceMessage], name = "ToSignUpServiceMessage"),
    new JsonSubTypes.Type(value = classOf[ToMessageServiceMessage], name = "ToMessageServiceMessage"),
  )
)
abstract class ToClusterMessage(val serializedInfo : String) extends JacksonSerializable{
  def route:MQRoute
}
