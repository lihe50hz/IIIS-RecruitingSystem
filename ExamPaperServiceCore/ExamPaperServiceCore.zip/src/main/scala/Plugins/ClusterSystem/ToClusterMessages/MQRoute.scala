package Plugins.ClusterSystem.ToClusterMessages

case class MQRoute(name:String)
