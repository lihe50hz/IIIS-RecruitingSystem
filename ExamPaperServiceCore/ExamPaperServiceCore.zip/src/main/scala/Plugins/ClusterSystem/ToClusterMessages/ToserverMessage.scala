
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.ToserverMessage.serverRoute

case class ToserverMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = serverRoute
}
object ToserverMessage{
  val serverRoute: MQRoute =MQRoute("serverRoute")
}
