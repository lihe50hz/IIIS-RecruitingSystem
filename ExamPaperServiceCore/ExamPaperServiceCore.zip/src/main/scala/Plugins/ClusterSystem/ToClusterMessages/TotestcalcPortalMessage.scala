
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotestcalcPortalMessage.testcalcPortalRoute

case class TotestcalcPortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = testcalcPortalRoute
}
object TotestcalcPortalMessage{
  val testcalcPortalRoute: MQRoute =MQRoute("testcalcPortalRoute")
}
