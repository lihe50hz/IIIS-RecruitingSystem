
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.ToRentCarSystemPortalMessage.rentCarSystemPortalRoute

case class ToRentCarSystemPortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = rentCarSystemPortalRoute
}
object ToRentCarSystemPortalMessage{
  val rentCarSystemPortalRoute: MQRoute =MQRoute("rentCarSystemPortalRoute")
}
