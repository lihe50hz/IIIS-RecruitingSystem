
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.Totype_safePortalMessage.type_safePortalRoute

case class Totype_safePortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = type_safePortalRoute
}
object Totype_safePortalMessage{
  val type_safePortalRoute: MQRoute =MQRoute("type_safePortalRoute")
}
