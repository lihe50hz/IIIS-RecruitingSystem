
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotestPortalMessage.testPortalRoute

case class TotestPortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = testPortalRoute
}
object TotestPortalMessage{
  val testPortalRoute: MQRoute =MQRoute("testPortalRoute")
}
