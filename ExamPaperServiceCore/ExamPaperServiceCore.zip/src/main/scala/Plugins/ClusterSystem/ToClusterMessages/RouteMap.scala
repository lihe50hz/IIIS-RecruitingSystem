
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.CommonUtils.ServiceCenter._

object RouteMap {
  val routeMap:Map[String, MQRoute]=Map(
    recruitingSystemPortalServiceCode -> ToRecruitingSystemPortalMessage.recruitingSystemPortalRoute,
    serverServiceCode -> ToserverMessage.serverRoute,
    testttttttServiceCode -> TotestttttttMessage.testttttttRoute,
    userServiceServiceCode -> ToUserServiceMessage.userServiceRoute,
    userServerServiceCode -> ToUserServerMessage.userServerRoute,
    imageServiceServiceCode -> ToImageServiceMessage.imageServiceRoute,
    examPaperServiceServiceCode -> ToExamPaperServiceMessage.examPaperServiceRoute,
    testCoreServiceCode -> TotestCoreMessage.testCoreRoute,
    testttServiceCode -> TotestttMessage.testttRoute,
    signUpServiceServiceCode -> ToSignUpServiceMessage.signUpServiceRoute,
    messageServiceServiceCode -> ToMessageServiceMessage.messageServiceRoute,
  )

}
