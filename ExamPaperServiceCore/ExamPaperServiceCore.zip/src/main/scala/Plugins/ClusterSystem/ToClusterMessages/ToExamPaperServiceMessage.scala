
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.ToExamPaperServiceMessage.examPaperServiceRoute

case class ToExamPaperServiceMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = examPaperServiceRoute
}
object ToExamPaperServiceMessage{
  val examPaperServiceRoute: MQRoute =MQRoute("examPaperServiceRoute")
}
