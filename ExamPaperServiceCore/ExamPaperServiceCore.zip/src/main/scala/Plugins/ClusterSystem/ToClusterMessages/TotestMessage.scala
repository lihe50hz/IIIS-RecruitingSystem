
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotestMessage.testRoute

case class TotestMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = testRoute
}
object TotestMessage{
  val testRoute: MQRoute =MQRoute("testRoute")
}
