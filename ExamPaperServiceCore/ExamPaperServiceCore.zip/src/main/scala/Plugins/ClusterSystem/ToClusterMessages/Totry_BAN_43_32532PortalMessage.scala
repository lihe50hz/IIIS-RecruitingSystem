
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.Totry_BAN_43_32532PortalMessage.try_BAN_43_32532PortalRoute

case class Totry_BAN_43_32532PortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = try_BAN_43_32532PortalRoute
}
object Totry_BAN_43_32532PortalMessage{
  val try_BAN_43_32532PortalRoute: MQRoute =MQRoute("try_BAN_43_32532PortalRoute")
}
