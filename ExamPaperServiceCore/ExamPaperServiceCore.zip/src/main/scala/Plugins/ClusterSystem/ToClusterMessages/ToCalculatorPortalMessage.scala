
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.ToCalculatorPortalMessage.calculatorPortalRoute

case class ToCalculatorPortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = calculatorPortalRoute
}
object ToCalculatorPortalMessage{
  val calculatorPortalRoute: MQRoute =MQRoute("calculatorPortalRoute")
}
