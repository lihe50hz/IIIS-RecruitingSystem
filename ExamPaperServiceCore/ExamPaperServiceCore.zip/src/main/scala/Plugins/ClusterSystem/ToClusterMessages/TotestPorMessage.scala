
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotestPorMessage.testPorRoute

case class TotestPorMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = testPorRoute
}
object TotestPorMessage{
  val testPorRoute: MQRoute =MQRoute("testPorRoute")
}
