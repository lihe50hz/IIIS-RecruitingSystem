
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotypesafePortalMessage.typesafePortalRoute

case class TotypesafePortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = typesafePortalRoute
}
object TotypesafePortalMessage{
  val typesafePortalRoute: MQRoute =MQRoute("typesafePortalRoute")
}
