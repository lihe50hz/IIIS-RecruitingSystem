
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotesttttttttPortalMessage.testtttttttPortalRoute

case class TotesttttttttPortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = testtttttttPortalRoute
}
object TotesttttttttPortalMessage{
  val testtttttttPortalRoute: MQRoute =MQRoute("testtttttttPortalRoute")
}
