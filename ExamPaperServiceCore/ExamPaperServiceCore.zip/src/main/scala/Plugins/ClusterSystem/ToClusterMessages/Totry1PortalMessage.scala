
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.Totry1PortalMessage.try1PortalRoute

case class Totry1PortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = try1PortalRoute
}
object Totry1PortalMessage{
  val try1PortalRoute: MQRoute =MQRoute("try1PortalRoute")
}
