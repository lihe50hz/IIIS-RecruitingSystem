
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotestttttttPanelPortalMessage.testttttttPanelPortalRoute

case class TotestttttttPanelPortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = testttttttPanelPortalRoute
}
object TotestttttttPanelPortalMessage{
  val testttttttPanelPortalRoute: MQRoute =MQRoute("testttttttPanelPortalRoute")
}
