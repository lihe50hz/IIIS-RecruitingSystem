
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.ToRecruitingSystemPortalMessage.recruitingSystemPortalRoute

case class ToRecruitingSystemPortalMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = recruitingSystemPortalRoute
}
object ToRecruitingSystemPortalMessage{
  val recruitingSystemPortalRoute: MQRoute =MQRoute("recruitingSystemPortalRoute")
}
