
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotestttMessage.testttRoute

case class TotestttMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = testttRoute
}
object TotestttMessage{
  val testttRoute: MQRoute =MQRoute("testttRoute")
}
