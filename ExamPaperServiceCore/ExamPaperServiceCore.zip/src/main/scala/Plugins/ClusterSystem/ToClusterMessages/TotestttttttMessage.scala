
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotestttttttMessage.testttttttRoute

case class TotestttttttMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = testttttttRoute
}
object TotestttttttMessage{
  val testttttttRoute: MQRoute =MQRoute("testttttttRoute")
}
