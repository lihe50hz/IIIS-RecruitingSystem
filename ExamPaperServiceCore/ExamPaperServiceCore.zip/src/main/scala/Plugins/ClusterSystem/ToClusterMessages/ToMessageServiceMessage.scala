
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.ToMessageServiceMessage.messageServiceRoute

case class ToMessageServiceMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = messageServiceRoute
}
object ToMessageServiceMessage{
  val messageServiceRoute: MQRoute =MQRoute("messageServiceRoute")
}
