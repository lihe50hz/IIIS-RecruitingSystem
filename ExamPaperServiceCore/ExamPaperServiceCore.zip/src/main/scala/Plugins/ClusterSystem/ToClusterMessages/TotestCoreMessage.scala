
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.TotestCoreMessage.testCoreRoute

case class TotestCoreMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = testCoreRoute
}
object TotestCoreMessage{
  val testCoreRoute: MQRoute =MQRoute("testCoreRoute")
}
