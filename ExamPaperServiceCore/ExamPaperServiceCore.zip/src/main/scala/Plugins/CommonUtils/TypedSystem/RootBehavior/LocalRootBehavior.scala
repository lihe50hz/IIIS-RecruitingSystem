package Plugins.CommonUtils.TypedSystem.RootBehavior

/** 这个是单机版本的RootBehavior，没有使用任何的Cluster元素，所以也不需要使用RabbitMQ */
object LocalRootBehavior extends RootBehavior
