package Plugins.ExamPaperServiceApi

import Plugins.ExamPaperServiceApi.MSAkkaExamPaperServiceMessageExtended


case class createExamPaper(
  
) extends MSAkkaExamPaperServiceMessageExtended[Int]
