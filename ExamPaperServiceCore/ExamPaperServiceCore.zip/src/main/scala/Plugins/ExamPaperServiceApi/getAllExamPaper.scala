package Plugins.ExamPaperServiceApi

import Plugins.ExamPaperServiceApi.MSAkkaExamPaperServiceMessageExtended
import Plugins.ExamPaperServiceShared.ExamPaper

case class getAllExamPaper(
  
) extends MSAkkaExamPaperServiceMessageExtended[Array[ExamPaper]]
