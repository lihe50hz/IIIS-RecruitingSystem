package Impl

import Plugins.ExamServiceShared.RunningExamInfo
import Plugins.CommonUtils.TypedSystem.API.{APIPlanner, PlanUUID}
import Plugins.ExamServiceApi.examStart
import Tables.RunningExamTable
import monix.eval.Task

object examStartPlanner extends APIPlanner[examStart]{
  override protected def plan(api: examStart)(implicit uuid: PlanUUID): Task[Boolean] = {
    val nowTime = System.currentTimeMillis()
    RunningExamTable.addExam(api.examPaper, api.startTime, api.startTime + api.examPaper.examDuration * 60L * 1000L)
      .onErrorHandle(_ => false)
    Task.now(true)
  }
}