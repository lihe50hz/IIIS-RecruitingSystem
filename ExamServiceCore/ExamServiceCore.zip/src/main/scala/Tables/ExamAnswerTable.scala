package Tables

import Plugins.ExamServiceShared.ExamAnswer
import Plugins.ExamServiceShared.ProblemAnswer
import Plugins.ExamServiceShared.Serializer
import Plugins.CommonUtils.ServiceCenter
import Plugins.CommonUtils.TypedSystem.API.PlanUUID
import Plugins.CommonUtils.TypedSystem.EventGenerator.{dbReadAction, dbReadActionSeq, dbWriteAction}
import monix.eval.Task
import slick.jdbc.PostgresProfile.api._
import slick.lifted.{ProvenShape, Tag, TableQuery}

case class ExamAnswerRow(
                        index: Option[Int] = None,
                        userName: String,
                        paperIndex: Int,
                        answers: Array[ProblemAnswer],
                        score: Double,
                        )

object Convert {
  def fromRowToShared(row: ExamAnswerRow): ExamAnswer = {
    ExamAnswer(row.index.getOrElse(-1), row.userName, row.paperIndex, row.answers, row.score)
  }
}



object MyImplicitsForExamAnswer {
  implicit val arrayProblemAnswerColumnType: BaseColumnType[Array[ProblemAnswer]] = {
    MappedColumnType.base[Array[ProblemAnswer], String](
      list => list.map(Serializer.fromProblemAnswerToString).mkString(","),
      string => string.split(",").map(Serializer.fromStringToProblemAnswer)
    )
  }
}

import MyImplicitsForExamAnswer._

class ExamAnswerTable(tag:Tag) extends Table[ExamAnswerRow](tag, ServiceCenter.mainSchema, "examAnswer") {

  def index:Rep[Int] = column[Int]("index", O.PrimaryKey, O.AutoInc)
  def userName:Rep[String] = column[String]("userName")
  def paperIndex:Rep[Int] = column[Int]("paperIndex")
  def answers:Rep[Array[ProblemAnswer]] = column[Array[ProblemAnswer]]("answers")
  def score:Rep[Double] = column[Double]("score")
  def * :ProvenShape[ExamAnswerRow] = (index.?, userName, paperIndex, answers, score).mapTo[ExamAnswerRow]
}

object ExamAnswerTable{
  val examAnswerTable = TableQuery[ExamAnswerTable]

  def addAnswer(answer:ExamAnswer)(implicit uuid:PlanUUID): Task[Int] = {
    val answerRow = ExamAnswerRow(userName = answer.userName,paperIndex = answer.paperIndex,
      answers = answer.answers, score = answer.score)
    dbWriteAction(examAnswerTable += answerRow)
  }

  def getAllRows()(implicit uuid: PlanUUID): Task[Array[ExamAnswer]] = {
    dbReadAction {
      examAnswerTable.result
    }.map(_.toArray.map(row => ExamAnswer(row.index.getOrElse(-1), row.userName, row.paperIndex, row.answers, row.score)))
  }

}
