package Tables

import Plugins.ExamServiceShared.ExamAnswer
import Plugins.ExamServiceShared.StudentScore
import Plugins.ExamServiceShared.Serializer
import Plugins.ExamPaperServiceShared.Problem
import Plugins.CommonUtils.ServiceCenter
import Plugins.CommonUtils.TypedSystem.API.PlanUUID
import Plugins.CommonUtils.TypedSystem.EventGenerator.{dbReadAction, dbReadActionSeq, dbWriteAction}
import monix.eval.Task
import slick.jdbc.PostgresProfile.api._
import slick.lifted.{ProvenShape, Tag, TableQuery}

case class StudentScoreRow(
                            userName: String,
                            totalScore: Double,
                            exams: Array[ExamAnswer],
                          )

object MyImplicitsForStudentScore {
  implicit val arrayExamAnswerColumnType: BaseColumnType[Array[ExamAnswer]] = {
    MappedColumnType.base[Array[ExamAnswer], String](
      list => list.map(Serializer.fromExamAnswerToString).mkString(","),
      string => string.split(",").map(Serializer.fromStringToExamAnswer)
    )
  }
}

import MyImplicitsForStudentScore._

class StudentScoreTable(tag:Tag) extends Table[StudentScoreRow](tag, ServiceCenter.mainSchema, "studentScore") {

  def userName:Rep[String] = column[String]("userName", O.PrimaryKey)
  def totalScore:Rep[Double] = column[Double]("totalScore")
  def exams:Rep[Array[ExamAnswer]] = column[Array[ExamAnswer]]("exams")

  def * :ProvenShape[StudentScoreRow] = (userName, totalScore, exams).mapTo[StudentScoreRow]
}

object StudentScoreTable{
  val studentScoreTable = TableQuery[StudentScoreTable]

  def addExamAnswer(exam: ExamAnswer)(implicit uuid:PlanUUID): Task[Int] = {
    dbReadAction(studentScoreTable.filter(_.userName === exam.userName).result.headOption).flatMap {
      case Some(row) => dbWriteAction {
        studentScoreTable.filter(_.userName === exam.userName).update{
          StudentScoreRow(row.userName, row.totalScore + exam.score, row.exams ++ Array(exam))
        }
      }
      case None => dbWriteAction{
        studentScoreTable += StudentScoreRow(exam.userName, exam.score, Array(exam))
      }
    }
  }

  def getAllRows()(implicit uuid: PlanUUID): Task[Array[StudentScore]] = {
    dbReadAction {
      studentScoreTable.result
    }.map(_.toArray.map(row => StudentScore(row.userName, row.totalScore, row.exams, 0)))
  }

}
