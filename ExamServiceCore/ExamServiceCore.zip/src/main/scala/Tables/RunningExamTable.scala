package Tables

import Plugins.ExamServiceShared.RunningExamInfo
import Plugins.CommonUtils.ServiceCenter
import Plugins.CommonUtils.TypedSystem.API.PlanUUID
import Plugins.CommonUtils.TypedSystem.EventGenerator.{dbReadAction, dbReadActionSeq, dbWriteAction}
import Plugins.ExamPaperServiceShared.ExamPaper
import monix.eval.Task
import slick.jdbc.PostgresProfile.api._
import slick.lifted.{ProvenShape, TableQuery, Tag}

case class RunningExamRow(
                        index:Int,
                        examName:String,
                        startTime:Long,
                        endTime:Long,
                       )

class RunningExamTable(tag:Tag) extends Table[RunningExamRow](tag, ServiceCenter.mainSchema, "examTimer") {
  def index:Rep[Int] = column[Int]("index", O.PrimaryKey)
  def examName:Rep[String] = column[String]("examName")
  def startTime:Rep[Long] = column[Long]("startTime")
  def endTime:Rep[Long] = column[Long]("endTime")

  def * :ProvenShape[RunningExamRow] = (index, examName, startTime, endTime).mapTo[RunningExamRow]
}

object RunningExamTable{
  val runningExamTable = TableQuery[RunningExamTable]

  def addExam(exam:ExamPaper, startTime:Long, endTime:Long)(implicit uuid:PlanUUID): Task[Int] = {
    val examRow = RunningExamRow(exam.index, exam.title, startTime, endTime)
    dbReadAction(runningExamTable.filter(_.index === exam.index).result.headOption).flatMap{
      case Some(row) => Task.raiseError(new Exception(s"The exam already exists!"))
      case None => dbWriteAction(runningExamTable += examRow)
    }
  }

  def getExamInfo(paperIndex:Int)(implicit uuid:PlanUUID): Task[RunningExamInfo] = {
    dbReadAction(runningExamTable.filter(_.index === paperIndex).result.headOption).flatMap{
      case Some(row) => Task.now(RunningExamInfo(System.currentTimeMillis(), row.startTime, row.endTime, row.index, row.examName))
      case None => Task.raiseError(new Exception(s"Exam $paperIndex not found!"))
    }
  }

  def getAllRows()(implicit uuid: PlanUUID): Task[Array[RunningExamInfo]] = {
    dbReadAction {
      runningExamTable.result
    }.map(_.toArray.map(row => RunningExamInfo(System.currentTimeMillis(), row.startTime, row.endTime, row.index, row.examName)))
  }

}
