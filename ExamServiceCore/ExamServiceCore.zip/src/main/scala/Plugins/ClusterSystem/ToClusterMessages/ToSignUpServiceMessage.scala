
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.ToSignUpServiceMessage.signUpServiceRoute

case class ToSignUpServiceMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = signUpServiceRoute
}
object ToSignUpServiceMessage{
  val signUpServiceRoute: MQRoute =MQRoute("signUpServiceRoute")
}
