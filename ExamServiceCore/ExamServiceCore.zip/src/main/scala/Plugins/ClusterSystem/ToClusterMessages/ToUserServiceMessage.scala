
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.ToUserServiceMessage.userServiceRoute

case class ToUserServiceMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = userServiceRoute
}
object ToUserServiceMessage{
  val userServiceRoute: MQRoute =MQRoute("userServiceRoute")
}
