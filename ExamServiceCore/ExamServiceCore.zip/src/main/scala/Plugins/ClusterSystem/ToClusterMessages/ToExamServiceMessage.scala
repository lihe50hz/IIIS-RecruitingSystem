
package Plugins.ClusterSystem.ToClusterMessages

import Plugins.ClusterSystem.ToClusterMessages.ToExamServiceMessage.examServiceRoute

case class ToExamServiceMessage(override val serializedInfo : String) extends ToClusterMessage(serializedInfo) {
  override def route: MQRoute = examServiceRoute
}
object ToExamServiceMessage{
  val examServiceRoute: MQRoute =MQRoute("examServiceRoute")
}
