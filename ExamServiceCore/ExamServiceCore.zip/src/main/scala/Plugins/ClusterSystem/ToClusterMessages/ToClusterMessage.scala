package Plugins.ClusterSystem.ToClusterMessages

import Plugins.CommonUtils.Types.JacksonSerializable
import com.fasterxml.jackson.annotation.{JsonSubTypes, JsonTypeInfo}


@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes(
  Array(
    new JsonSubTypes.Type(value = classOf[ToExamPaperServiceMessage], name = "ToExamPaperServiceMessage"),
    new JsonSubTypes.Type(value = classOf[ToExamServiceMessage], name = "ToExamServiceMessage"),
    new JsonSubTypes.Type(value = classOf[ToImageServiceMessage], name = "ToImageServiceMessage"),
    new JsonSubTypes.Type(value = classOf[ToMessageServiceMessage], name = "ToMessageServiceMessage"),
    new JsonSubTypes.Type(value = classOf[ToRecruitingSystemPortalMessage], name = "ToRecruitingSystemPortalMessage"),  
    new JsonSubTypes.Type(value = classOf[ToSignUpServiceMessage], name = "ToSignUpServiceMessage"),
    new JsonSubTypes.Type(value = classOf[ToUserServiceMessage], name = "ToUserServiceMessage"),
  )
)
abstract class ToClusterMessage(val serializedInfo : String) extends JacksonSerializable{
  def route:MQRoute
}
