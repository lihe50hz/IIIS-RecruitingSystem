package Plugins.ClusterSystem.ToClusterMessages

import Plugins.CommonUtils.ServiceCenter._

object RouteMap {
  val routeMap:Map[String, MQRoute]=Map(
    examPaperServiceServiceCode -> ToExamPaperServiceMessage.examPaperServiceRoute,
    examServiceServiceCode -> ToExamServiceMessage.examServiceRoute,
    imageServiceServiceCode -> ToImageServiceMessage.imageServiceRoute,
    messageServiceServiceCode -> ToMessageServiceMessage.messageServiceRoute,
    recruitingSystemPortalServiceCode -> ToRecruitingSystemPortalMessage.recruitingSystemPortalRoute,
    signUpServiceServiceCode -> ToSignUpServiceMessage.signUpServiceRoute,
    userServiceServiceCode -> ToUserServiceMessage.userServiceRoute,   
  )

}
