package Plugins.ExamServiceApi

import Plugins.ExamServiceApi.MSAkkaExamServiceMessageExtended
import Plugins.ExamServiceShared.{RunningExamInfo}

case class getAllExams(
                         ) extends MSAkkaExamServiceMessageExtended[Array[RunningExamInfo]]
