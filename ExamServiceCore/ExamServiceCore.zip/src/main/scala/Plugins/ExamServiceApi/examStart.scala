package Plugins.ExamServiceApi

import Plugins.ExamPaperServiceShared.ExamPaper
import Plugins.ExamServiceApi.MSAkkaExamServiceMessageExtended


case class examStart(
                      examPaper:ExamPaper,
                      startTime:Long,
) extends MSAkkaExamServiceMessageExtended[Boolean]
