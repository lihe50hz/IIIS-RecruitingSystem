package Plugins.CommonUtils

import Globals.GlobalVariables.serviceCode


/** 保存所有的服务注册信息 */
object ServiceCenter {

  val examPaperServiceServiceCode = "A000001"
  val examServiceServiceCode = "A000002"
  val imageServiceServiceCode = "A000003"
  val messageServiceServiceCode = "A000004"
  val recruitingSystemPortalServiceCode = "A000006"
  val signUpServiceServiceCode = "A000006"
  val userServiceServiceCode = "A000007"
  

  /** ***************************************************************** */

  val fullNameMap: Map[String, String] = Map(
    examPaperServiceServiceCode -> "ExamPaperService",
    examServiceServiceCode -> "ExamService",
    imageServiceServiceCode -> "ImageService",
    messageServiceServiceCode -> "MessageService",
    recruitingSystemPortalServiceCode -> "RecruitingSystemPortal",
    signUpServiceServiceCode -> "SignUpService",
    userServiceServiceCode -> "UserService"
  )

  val portalPortMap: Map[String, Int] = Map(
    recruitingSystemPortalServiceCode -> 6000,
  )

  def portMap(serviceCode: String): Int = {
    serviceCode.drop(1).toInt +
      (if (serviceCode.head == 'A') 10000 else if (serviceCode.head == 'D') 20000 else 30000)
  }

  def serviceName(serviceCode: String): String = {
    fullNameMap(serviceCode).toLowerCase
  }

  def serverHostName: String = "localhost"

  def dbServerName: String = "postgres-service"

  def serverPort(serviceCode: String): String = serverHostName + ":" + portMap(serviceCode)

  def mainSchema: Option[String] = Some(serviceName(serviceCode).replace("-", "_"))

  val seedNodeName: String = List(serviceCode).map(
    "\"akka://QianFangCluster@" + serverPort(_) + "\""
  ).reduce(_ + "," + _)

  lazy val servicePort: Int = portMap(serviceCode)
  lazy val serviceFullName: String = fullNameMap(serviceCode)
}

