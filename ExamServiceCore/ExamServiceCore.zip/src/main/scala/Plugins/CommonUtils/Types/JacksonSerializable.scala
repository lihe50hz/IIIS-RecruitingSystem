package Plugins.CommonUtils.Types

trait JacksonSerializable
