package Plugins.ExamServiceShared

import Plugins.CommonUtils.Types.JacksonSerializable


import Plugins.ExamPaperServiceShared.Problem

case class ProblemAnswer(
  problem:Problem,
  answered:Boolean,
  studentChoice:Int,
  studentAnswer:String,
  studentImage:Int,
  score:Double,
  
) extends JacksonSerializable