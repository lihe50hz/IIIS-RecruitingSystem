package Plugins.ExamServiceShared

import Plugins.ExamPaperServiceShared.Problem

object Serializer{
  def fromProblemToString(problem: Problem): String = {
    ("{" + problem.problemType + "," +
      problem.description + "," +
      problem.image.toString + "," +
      problem.choiceCnt.toString + "," + "[" +
      problem.choices.mkString("/") + "]" + "}")
  }
  def fromStringToProblem(string: String): Problem = {
    val strList = string.replace("{", "").replace("}", "").split(",")
    Problem(strList(0), strList(1), strList(2).toInt, strList(3).toInt,
      strList(4).replace("[", "").replace("]", "").split("/"))
  }
  def fromProblemAnswerToString(answer: ProblemAnswer): String = {
    ("(" + fromProblemToString(answer.problem) + "," +
      answer.answered.toString + "," +
      answer.studentChoice.toString + "," +
      answer.studentAnswer + "," +
      answer.studentImage.toString + "," +
      answer.score.toString + ")")
  }
  def fromStringToProblemAnswer(string: String): ProblemAnswer = {
    val strList = string.replace("(", "").replace(")", "").split(",")
    ProblemAnswer(fromStringToProblem(strList(0)), strList(1).toBoolean, strList(2).toInt, strList(3),
      strList(4).toInt, strList(5).toDouble)
  }

  def fromExamAnswerToString(answer: ExamAnswer): String = {
    ("<" + answer.index.toString + "," +
      answer.userName + "," +
      answer.paperIndex.toString + "," +
      "%[" + answer.answers.map(fromProblemAnswerToString).mkString("-") + "]%" + "," +
      answer.score.toString + ">")
  }

  def fromStringToExamAnswer(string: String): ExamAnswer = {
    val strList = string.replace("<", "").replace(">", "").split(",")
    ExamAnswer(strList(0).toInt, strList(1), strList(2).toInt,
      strList(3).replace("%[", "").replace("]%", "")
        .split("-").map(fromStringToProblemAnswer),
      strList(4).toDouble)
  }

}